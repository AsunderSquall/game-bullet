class GameStorage {
  constructor() {
    this.cache = new Map();
  }

  async load(key, defaultData = {}) {
    try {
      const res = await fetch(`../../data/cur/${key}`);
      if (res.ok) {
        const data = await res.json();
        this.cache.set(key, data);
        console.log(`Loaded ${key}`, data);
        return data;
      }
    } catch (err) {
      console.warn(`File ../../data/cur/${key} not found, using default`);
    }

    this.cache.set(key, defaultData);
    this.save(key);
    return defaultData;
  }
  async load_global(key, defaultData = {}) {
    try {
      const res = await fetch(`../../data/archive1/${key}`);
      if (res.ok) {
        const data = await res.json();
        this.cache.set(key, data);
        console.log(`Loaded ${key}`, data);
        return data;
      }
    } catch (err) {
      console.warn(`File ../../data/cur/${key} not found, using default`);
    }

    this.cache.set(key, defaultData);
    this.save(key);
    return defaultData;
  }

  get(key) {
    return this.cache.get(key);
  }

  async save(key) {
    const data = this.cache.get(key);
    if (!data) return;

    localStorage.setItem(`danmaku_${key}`, JSON.stringify(data, null, 2));
  }

  set(key, data) {
    this.cache.set(key, data);
    this.save(key);
  }
}

export const storage = new GameStorage();