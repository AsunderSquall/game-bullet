import { storage } from '../utils/storage.js';
import { tempPlayerDefault } from '../defaults/tempPlayerDefault.js';
import { createCardFromId } from '../cards/CardFactory.js';

let maxPassiveSlots = 8;  // 从存档读取
let maxEnergy = 5;        // 从存档读取

let currentWeaponCard = null;
let currentPassiveCards = [];  // 数组，存卡实例（允许多张同ID）

let deckInventory = {};  // { id: remainingCount }

// DOM 元素
let weaponSlot, passiveSlots, deckContainer, display, confirmBtn;
async function main() {
  try {
    const response = await fetch('src/ui/SelectMain.html');  // 你的路径
    if (!response.ok) throw new Error('加载失败');
    const htmlContent = await response.text();
    document.body.innerHTML = htmlContent;
  } catch (err) {
    console.error(err);
    document.body.innerHTML = '<h1 style="color:red;">加载失败喵～</h1>';
    return;
  }

  weaponSlot = document.getElementById('weapon-slot');
  passiveSlots = document.querySelectorAll('.passive-slot');
  deckContainer = document.getElementById('deck-container');
  display = {
    weaponName: document.getElementById('weapon-name'),
    atk: document.getElementById('atk'),
    speed: document.getElementById('speed'),
    maxhp: document.getElementById('maxhp'),
    hp: document.getElementById('hp'),
    bomb: document.getElementById('bomb'),
    usedSlots: document.getElementById('used-slots'),
    maxSlots: document.getElementById('max-slots'),
    usedEnergy: document.getElementById('used-energy'),
    maxEnergy: document.getElementById('max-energy'),
    bomb: document.getElementById('bomb'),
    hitRadius: document.getElementById('hit-radius'),
    lives: document.getElementById('lives'),
    power: document.getElementById('power'),
    upgrades: document.getElementById('upgrades')
  };
  confirmBtn = document.getElementById('confirm-btn');

  if (!deckContainer || !weaponSlot || !confirmBtn) {
    console.error('元素没找到！');
    return;
  }

  await init();
}

// 初始化选卡内容
async function init() {
  const globalSave = await storage.load_global('global.json', { deck: {} });
  console.log(globalSave);
  deckInventory = { ...globalSave.deck };  // 复制库存
  maxPassiveSlots = globalSave.max_passive_slots || 8;
  maxEnergy = globalSave.max_energy || 5;
  console.log(maxPassiveSlots,maxEnergy);

  // 生成卡牌库：每种卡只显示一张 + 数量标签
  for (const id in globalSave.deck) {
    if (globalSave.deck[id] > 0) {
      const card = createCardFromId(id);
      if (card) createDeckCardPrototype(card, globalSave.deck[id]);
    }
  }

  setupDragAndDrop();
  recalculateParams();
}

// 创建原型卡（只一张，带数量）
function createDeckCardPrototype(card, count) {
  const div = document.createElement('div');
  div.className = `card ${card.type} ${count === 0 ? 'disabled' : ''}`;
  div.draggable = count > 0;
  div.innerHTML = `
    <img src="${card.icon}" alt="${card.name}" class="card-icon">
    <div class="card-name">${card.name}</div>
    <div class="card-description">${card.description}</div>
    <div class="card-count">x${count}</div>
    ${card.energy > 0 ? `<div class="card-energy">所需能量: ${card.energy}</div>` : ''}
  `;
  div.dataset.id = card.id;

  // 更新数量函数
  const updateCount = () => {
    const currentCount = deckInventory[card.id] || 0;
    div.querySelector('.card-count').textContent = `x${currentCount}`;
    div.draggable = currentCount > 0;
    div.classList.toggle('disabled', currentCount === 0);
  };

  div.addEventListener('dragstart', e => {
    if (deckInventory[card.id] > 0) {
      e.dataTransfer.setData('cardId', card.id);
      e.dataTransfer.setData('cardType', card.type);
    }
  });

  div.updateCount = updateCount;

  deckContainer.appendChild(div);
}

function getCurrentEnergyCost() {
  let total = 0;
  if (currentWeaponCard) total += currentWeaponCard.energy || 0;
  currentPassiveCards.forEach(c => total += c.energy || 0);
  return total;
}

function setupDragAndDrop() {
  // 超级重要！！所有可放置区域都要加 dragover
  weaponSlot.addEventListener('dragover', e => e.preventDefault());
  passiveSlots.forEach(slot => {
    slot.addEventListener('dragover', e => e.preventDefault());  // 必须加！！
  });

  // 武器槽 drop（加库存检查更安全）
  weaponSlot.addEventListener('drop', e => {
    e.preventDefault();
    const id = e.dataTransfer.getData('cardId');
    const type = e.dataTransfer.getData('cardType');
    if (type === 'weapon' && deckInventory[id] > 0) {
      // 如果已有武器，先还回去（超级人性化～）
      if (currentWeaponCard) {
        deckInventory[currentWeaponCard.id]++;
        updateAllDeckCounts();
      }
      currentWeaponCard = createCardFromId(id);
      deckInventory[id]--;
      updateAllDeckCounts();
      renderSlots();
      recalculateParams();
    }
  });

  // 被动槽 drop（核心修复！）
  passiveSlots.forEach(slot => {
    slot.addEventListener('drop', e => {
      e.preventDefault();
      const id = e.dataTransfer.getData('cardId');
      const type = e.dataTransfer.getData('cardType');
      if (type === 'passive' && deckInventory[id] > 0) {
        const card = createCardFromId(id);
        const newTotalEnergy = getCurrentEnergyCost() + (card.energy || 0);
        if (currentPassiveCards.length < maxPassiveSlots && newTotalEnergy <= maxEnergy) {
          currentPassiveCards.push(card);
          deckInventory[id]--;
          updateAllDeckCounts();
          renderSlots();
          recalculateParams();
        } else {
          // 加个提示更好～（可选）
          console.log('不能拖入：槽位或能量不足喵～');
        }
      }
    });

    // 右键移除（保持不变）
    slot.addEventListener('contextmenu', e => {
      e.preventDefault();
      const index = Array.from(passiveSlots).indexOf(slot);
      const removedCard = currentPassiveCards[index];
      if (removedCard) {
        currentPassiveCards.splice(index, 1);
        deckInventory[removedCard.id]++;
        updateAllDeckCounts();
        renderSlots();
        recalculateParams();
      }
    });
  });
}
function renderSlots() {
  weaponSlot.innerHTML = currentWeaponCard 
    ? `
      <img src="${currentWeaponCard.icon}" alt="${currentWeaponCard.name}" class="slot-icon">
      <div style="font-size:11px;margin-top:4px;">${currentWeaponCard.name}</div>
      `
    : '武器槽<br>(限1)';

  passiveSlots.forEach((slot, i) => {
    const card = currentPassiveCards[i];
    slot.innerHTML = card 
      ? `
        <img src="${card.icon}" alt="${card.name}" class="slot-icon">
        <div style="font-size:10px;margin-top:4px;">${card.name}</div>
        `
      : '';
  });
}

const style = document.createElement('style');
style.textContent = `
  .slot-icon {
    width: 80px;
    height: 80px;
    object-fit: contain;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.5);
  }
`;
document.head.appendChild(style);

function recalculateParams() {
  const temp = { ...tempPlayerDefault };
  temp.upgrades = []
  if (currentWeaponCard) currentWeaponCard.apply(temp);
  currentPassiveCards.forEach(card => card.apply(temp));

  display.weaponName.textContent = currentWeaponCard ? currentWeaponCard.name : '无';
  display.atk.textContent = temp.attackPower ?? 28;
  display.speed.textContent = (temp.attackSpeed ?? 0.09).toFixed(3);
  display.maxhp.textContent = temp.maxHealth ?? 100;
  display.hp.textContent = temp.health ?? 100;
  display.bomb.textContent = temp.bombs ?? 5;
  display.usedSlots.textContent = currentPassiveCards.length + (currentWeaponCard ? 1 : 0);
  display.usedEnergy.textContent = getCurrentEnergyCost();
  display.maxEnergy.textContent = maxEnergy;
  display.maxSlots.textContent = maxPassiveSlots+1;
  display.power.textContent = temp.power;
  display.hitRadius.textContent = temp.hitRadius;
  display.lives.textContent = temp.lives;
  display.upgrades.textContent = temp.upgrades;
  
}
function updateAllDeckCounts() {
  document.querySelectorAll('.card').forEach(protoCard => {
    if (protoCard.updateCount) protoCard.updateCount();
  });
}
// 启动！
main();